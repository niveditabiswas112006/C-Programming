// Create a program for Matrix Addition using 2D array.
#include <iostream>
using namespace std;
int addMatrices(int A[2][2], int B[2][2], int result[2][2], int rows, int cols) 
{
    for (int i = 0; i < rows; i++) 
    {
        for (int j = 0; j < cols; j++) 
        {
            result[i][j] = A[i][j] + B[i][j];
        }
    }
}
int displayMatrix(int matrix[2][2], int rows, int cols) 
{
    for (int i = 0; i < rows; i++) 
    {
        for (int j = 0; j < cols; j++) 
        {
            cout<< matrix[i][j]<<" ";
        }
        cout<<endl;
    }
}
int main() 
{
    int A[2][2], B[2][2], result[2][2];
    int rows = 2, cols = 2;
    cout << "Enter elements for matrix A (2x2): "<< endl;
    for (int i = 0; i < rows; i++) 
    {
        for (int j = 0; j < cols; j++) 
        {
            cout<<"A[" << i + 1 << "][" << j + 1 << "]: ";
            cin>>A[i][j];
        }
    }
    cout <<"Enter elements for matrix B (2x2): "<< endl;
    for (int i = 0; i < rows; i++) 
    {
        for (int j = 0; j < cols; j++) 
        {
            cout << "B[" << i + 1 << "][" << j + 1 << "]: ";
            cin >> B[i][j];
        }
    }
    addMatrices(A, B, result, rows, cols);
    cout << "\nThe result of adding matrices A and B is:" << endl;
    displayMatrix(result, rows, cols);
    return 0;
}